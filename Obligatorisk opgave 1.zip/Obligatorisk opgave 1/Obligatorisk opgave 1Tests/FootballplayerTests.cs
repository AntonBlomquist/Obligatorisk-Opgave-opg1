﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Obligatorisk_opgave_1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Obligatorisk_opgave_1.Tests {
    [TestClass]
    public class FootballplayerTests {
        private Footballplayer player;

        [TestInitialize]
        public void Start() {
            player = new Footballplayer("Anton", 5, 100);
        }

        [TestMethod]
        public void TestName() { //Skal være minimum 4 karakterer
            player.Name = "Anton"; //Virker
            Assert.AreEqual("Anton", player.Name);
            player.Name = "Kim"; //Virker ikke, under 4 karakterer
            Assert.AreEqual("Kim", player.Name); //Tjekker om værdien er blevet sat
        }

        [TestMethod]
        public void TestPrice() { //Skal være over 0
            player.Price = 100;
            Assert.AreEqual(100, player.Price);
            player.Price = 0;
            Assert.AreEqual(0, player.Price);
        }

        [TestMethod]
        public void TestShirtNumber() { //Skal være mellem 0-100
            player.ShirtNumber = 25;
            Assert.AreEqual(25, player.ShirtNumber);
            player.ShirtNumber = 125;
            Assert.AreEqual(125, player.ShirtNumber);
        }

    }
}