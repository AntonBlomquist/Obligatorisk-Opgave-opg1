﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Obligatorisk_opgave_1 {
    public class Footballplayer {

        public int Id { get; private set; }
        private string _name;
        private int _price;
        private int _shirtNumber;
        private static int idcount = 1;

        public Footballplayer(string name, int price, int shirtnumber) {
            Name = name;
            Price = price;
            ShirtNumber = shirtnumber;
            Id = idcount++;
        }

        public string Name {
            get {
                return _name;
            }
            set {
                if (value.Length >= 4) {
                    _name = value;
                } else {
                    throw new ArgumentException("Name has to be 4 or more characters long");
                }
            }
        }

        public int Price {
            get {
                return _price;
            }
            set {
                if(value>0) {
                    _price = value;
                }else {
                    throw new ArgumentException("Price has to be more than 0");
                }
            }
        }

        public int ShirtNumber {
            get {
                return _shirtNumber;
            }
            set {
                if(value>=1 && value<=100) {
                    _shirtNumber = value;
                }else {
                    throw new ArgumentOutOfRangeException("Shirtnumber has to be between 1-100");
                }
            }
        }
    }
}
